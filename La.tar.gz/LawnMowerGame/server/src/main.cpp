#include <iostream>
#include <spdlog/spdlog.h>

int main() {
    spdlog::info("LawnMower Server 启动中...");
    spdlog::info("服务端主程序 - 等待实现网络模块");
    
    // TODO: 初始化网络服务器
    // TODO: 启动游戏循环
    
    return 0;
}
